<?php require views_path('partials/header');?>

	<div class="container-fluid border rounded p-4 m-2 col-lg-4 mx-auto">

		<form method="post" enctype="multipart/form-data">

			<h5 class="text-primary"><i class="fa fa-hamburger"></i> Add Product</h5>
			
			<div class="mb-3">
			  <label for="productControlInput1" class="form-label">Product description :*</label>
			  <input name="description" type="text" class="form-control <?=!empty($errors['description']) ? 'border-danger':''?>" id="productControlInput1" placeholder="Product description">
			  <?php if(!empty($errors['description'])):?>
					<small class="text-danger"><?=$errors['description']?></small>
				<?php endif;?>
			</div>
			
			<div class="mb-3">
			  <label for="barcodeControlInput1" class="form-label">Barcode <small class="text-muted">(optional)</small></label>
			  <input name="barcode" type="text" class="form-control <?=!empty($errors['barcode']) ? 'border-danger':''?>" id="barcodeControlInput1" placeholder="Product barcode">
			  <?php if(!empty($errors['barcode'])):?>
					<small class="text-danger"><?=$errors['barcode']?></small>
				<?php endif;?>
			</div>
			<div class="mb-3">
			  <label for="lot" class="form-label">Lot<small class="text-muted"> (optional)</small></label>
			  <input name="lot" type="text" class="form-control <?=!empty($errors['lot']) ? 'border-danger':''?>" id="lot" placeholder="ARRIVAGE">
			  <?php if(!empty($errors['lot'])):?>
					<small class="text-danger"><?=$errors['lot']?></small>
				<?php endif;?>
			</div>
            <br>
			<div class="mb-3">
			  <label for="shop" class="form-label">Shop <small class="text-muted">(optional) 2.Maurice</small></label>
			  <input name="shop" type="text" class="form-control <?=!empty($errors['shop']) ? 'border-danger':''?>" id="shop" value="2">
			  <?php if(!empty($errors['shop'])):?>
					<small class="text-danger"><?=$errors['shop']?></small>
				<?php endif;?>
			</div>
            <br>
			<div class="input-group mb-3">
			  <span class="input-group-text">Qty :*</span>
			  <input name="qty" value="1" type="number" class="form-control <?=!empty($errors['qty']) ? 'border-danger':''?>" placeholder="Quantity" aria-label="Quantity">
			  <span class="input-group-text">Amount:*</span>
			  <input name="amount" value="0.00" step="0.05" type="number" class="form-control <?=!empty($errors['amount']) ? 'border-danger':''?>" placeholder="Amount" aria-label="Amount">
			</div>
				<?php if(!empty($errors['qty'])):?>
					<small class="text-danger"><?=$errors['qty']?></small>
				<?php endif;?>
				<?php if(!empty($errors['amount'])):?>
					<small class="text-danger"><?=$errors['amount']?></small>
				<?php endif;?>
				<br>
			<div class="mb-3">
			    <label class="form-label small text-muted">Purchase Price (optional)</label>
			    <input name="purchase_price" value="<?=set_value('purchase_price',$row['purchase_price'])?>" type="number" step="0.01" class="form-control <?=!empty($errors['purchase_price']) ? 'border-danger':''?>" placeholder="Purchase Price" aria-label="Purchase Price" >
			</div>
			<div class="mb-3">
			    <label class="form-label small text-muted">Expiry Date (optional)</label>
			    <input name="expire_date" value="<?=set_value('expire_date',$row['expire_date'])?>" type="date" class="form-control <?=!empty($errors['expire_date']) ? 'border-danger':''?>" placeholder="Expiry Date" aria-label="Expiry Date" >
			</div>
			<div class="mb-3">
			  <label for="formFile" class="form-label">Product Image *</label>
			  <input name="image" class="form-control <?=!empty($errors['image']) ? 'border-danger':''?>" type="file" id="formFile">
			  <?php if(!empty($errors['image'])):?>
					<small class="text-danger"><?=$errors['image']?></small>
				<?php endif;?>
			</div>

			<br>
			<button class="btn btn-danger float-end">Save</button>
			<a href="index.php?pg=admin&tab=products">
				<button type="button" class="btn btn-primary">Cancel</button>
			</a>
		</form>
	</div>

<?php require views_path('partials/footer');?>